"""気象庁アメダスを取り、S3 の latest.json を更新する。"""

import json
import os
import urllib.request
from datetime import datetime
from zoneinfo import ZoneInfo

import boto3
from botocore.exceptions import ClientError

JST = ZoneInfo("Asia/Tokyo")
LATEST_TIME_URL = "https://www.jma.go.jp/bosai/amedas/data/latest_time.txt"
MAP_URL = "https://www.jma.go.jp/bosai/amedas/data/map/{stamp}.json"
DT_FMT = "%Y-%m-%d %H:%M:%S"

s3 = boto3.client("s3")
BUCKET = os.environ["DATA_BUCKET"]


def handler(event, context):
    t = fetch_latest_time()
    current = t.strftime(DT_FMT)

    prev = read_json("latest.json")
    if prev and prev.get("datetime") == current:
        return {"skipped": True, "datetime": current}

    raw = fetch_json(MAP_URL.format(stamp=t.strftime("%Y%m%d%H%M%S")))
    observations = []
    for bosai_id, row in raw.items():
        item = normalize(bosai_id, row, current)
        if item is not None:
            observations.append(item)

    raining = [o for o in observations if (o["precip"] or 0) > 0]
    body = {
        "datetime": current,
        "raining_count": len(raining),
        "wettest": max(raining, key=lambda o: o["precip"], default=None),
        "observations": observations,
    }
    put_json("latest.json", body)
    return {"datetime": current, "stations": len(observations)}


def fetch_latest_time():
    text = fetch_text(LATEST_TIME_URL).strip()
    return datetime.fromisoformat(text).astimezone(JST)


def normalize(bosai_id, row, current):
    temp = value_of(row, "temp")
    precip = value_of(row, "precipitation1h")
    wind = value_of(row, "wind")
    direction = value_of(row, "windDirection")
    if temp is None and precip is None and wind is None:
        return None
    return {
        "datetime": current,
        "station_id": bosai_id,  # 対応表ができたら obsdl ID に置き換える
        "temp": temp,
        "precip": precip,
        "wind_speed": wind,
        "wind_dir": None if direction is None else str(int(direction)),
    }


def value_of(row, key):
    """[値, 品質フラグ]。フラグが 0 のときだけ値を採用する。"""
    cell = row.get(key)
    if not isinstance(cell, list) or len(cell) < 2 or cell[1] != 0 or cell[0] is None:
        return None
    return cell[0]


def fetch_text(url):
    req = urllib.request.Request(url, headers={"User-Agent": "raincast"})
    with urllib.request.urlopen(req, timeout=10) as res:
        return res.read().decode("utf-8")


def fetch_json(url):
    return json.loads(fetch_text(url))


def read_json(key):
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=key)
    except ClientError as exc:
        if exc.response["Error"]["Code"] in ("NoSuchKey", "404"):
            return None
        raise
    return json.loads(obj["Body"].read())


def put_json(key, body):
    s3.put_object(
        Bucket=BUCKET,
        Key=key,
        Body=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        ContentType="application/json",
    )
